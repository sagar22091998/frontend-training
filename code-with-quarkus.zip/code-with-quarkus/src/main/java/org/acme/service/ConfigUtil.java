package org.acme.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


@Slf4j
@Data
public class ConfigUtil {
    private final static String CONFIGURATION_FILE = "/home/sagar.bhattacharya/Desktop/dev/code-with-quarkus/src/main/resources/config.json";

    public HashMap<String, String> readJsonConfig() {
        ObjectMapper mapper = new ObjectMapper();
        File file = new File(CONFIGURATION_FILE);
        HashMap<String, String> jsonData= new HashMap<>();

        try {
            Map<String, String> map = mapper.readValue(file, Map.class);
            for (Map.Entry<String, String> entry : map.entrySet()) {
                jsonData.put(entry.getKey(),entry.getValue());
            }
        } catch (IOException e) {
            log.info("Config File Not Found");
            throw new RuntimeException(e);
        }

        return jsonData;
    }
}