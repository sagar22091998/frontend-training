package org.acme.service;

import com.google.cloud.dns.*;
import com.google.common.collect.Iterables;
import eu.roboflax.cloudflare.CloudflareAccess;
import eu.roboflax.cloudflare.CloudflareRequest;
import eu.roboflax.cloudflare.CloudflareResponse;
import eu.roboflax.cloudflare.constants.Category;
import eu.roboflax.cloudflare.objects.dns.DNSRecord;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public class CloudflareDNSUtil {
    public void createDNS(final String tenant) {
        final ConfigUtil config = new ConfigUtil();
        final CloudflareAccess cfAccess = new CloudflareAccess(config.readJsonConfig().get("cloudflareAPIKey"),config.readJsonConfig().get("cloudflareEmail"));

        final CloudflareResponse<List<DNSRecord>> response =
                new CloudflareRequest( Category.LIST_DNS_RECORDS, cfAccess )
                        .identifiers(config.readJsonConfig().get("zoneCloudflareID"))
                        .asObjectList(DNSRecord.class);
        List<DNSRecord> records = response.getObject();

        // Checking if already present
        if(records.stream().filter(record -> record.getName().replace("." + record.getZoneName(),"").equals(tenant)).count() > 0){
            log.info("DNS Already Present");
            return;
        };

        // Creating new DNS Record if not present
        CloudflareResponse<DNSRecord> res = new CloudflareRequest( Category.CREATE_DNS_RECORD, cfAccess )
                .identifiers(config.readJsonConfig().get("zoneCloudflareID"))
                .body("type","CNAME")
                .body( "name", tenant) //DNS Prefix
                .body("content", config.readJsonConfig().get("cname")) // CNAME value from config
                .body("ttl",1) //TTL is auto
                .asObject( DNSRecord.class );
    }

    public void deleteDNS(final String tenant) {
        final ConfigUtil config = new ConfigUtil();
        final CloudflareAccess cfAccess = new CloudflareAccess(config.readJsonConfig().get("cloudflareAPIKey"),config.readJsonConfig().get("cloudflareEmail"));

        final CloudflareResponse<List<DNSRecord>> response =
                new CloudflareRequest( Category.LIST_DNS_RECORDS, cfAccess )
                        .identifiers(config.readJsonConfig().get("zoneCloudflareID"))
                        .asObjectList(DNSRecord.class);
        List<DNSRecord> records = response.getObject();

        // Checking if not present
        if(records.stream().filter(record -> record.getName().replace("." + record.getZoneName(),"").equals(tenant)).count() == 0){
            log.info("DNS Not Present/Already Removed");
            return;
        };

        // Deleting if present
        records.stream().forEach(record-> {
            final String DNSTenantTobeDeleted = record.getName().replace("."+record.getZoneName(),"");
            if(DNSTenantTobeDeleted.equals(tenant)){
                new CloudflareRequest( Category.DELETE_DNS_RECORD, cfAccess )
                        .identifiers(config.readJsonConfig().get("zoneCloudflareID"),record.getId())
                        .asObject(DNSRecord.class);
           }
        });
    }
}
