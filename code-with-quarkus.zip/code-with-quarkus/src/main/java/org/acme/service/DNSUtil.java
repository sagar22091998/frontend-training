package org.acme.service;

import com.google.cloud.dns.*;
import com.google.common.collect.Iterables;
import lombok.extern.slf4j.Slf4j;

import javax.enterprise.context.ApplicationScoped;
import java.util.concurrent.TimeUnit;

@Slf4j
@ApplicationScoped
public class DNSUtil {
    public void createDNS(final String tenant) {
        final ConfigUtil reader = new ConfigUtil();

        final Dns dns = DnsOptions.getDefaultInstance().getService();
        final Zone zone = dns.getZone(reader.readJsonConfig().get("zone"));
        final String newNamespace = tenant + "." + zone.getDnsName();

        // Checking if DNS already present
        if(!Iterables.isEmpty(zone.listRecordSets(Dns.RecordSetListOption.dnsName(newNamespace)).iterateAll())){
            log.info("Namespace Already Present");
            return;
        }

        final RecordSet toCreate = RecordSet.newBuilder(newNamespace, RecordSet.Type.CNAME)
                .setTtl(1, TimeUnit.DAYS)
                .addRecord(reader.readJsonConfig().get("cname"))
                .build();

        final ChangeRequestInfo.Builder changeBuilder = ChangeRequestInfo.newBuilder().add(toCreate);
        final ChangeRequestInfo changeRequest = changeBuilder.build();
        zone.applyChangeRequest(changeRequest);
    }

    public void tempCreate(final String namespacePrefix) {
//        JsonFileReader reader = new JsonFileReader();
//        reader.readJsonFileByPath("/home/sagar.bhattacharya/Desktop/dev/code-with-quarkus/key2.json");

//        final Dns dns = DnsOptions.getDefaultInstance().getService();
//        final Zone zone = dns.getZone(Constants.ZONE_NAME);




//
//        // Creating new DNS if not present
//        final RecordSet toCreate =
//                RecordSet.newBuilder(newNamespace, Constants.RECORD_SET_TYPE)
//                        .setTtl(Constants.TTL_IN_DAYS, Constants.TIME_UNIT)
//                        .addRecord(Constants.CNAMEVal)
//                        .build();
//
//        final ChangeRequestInfo.Builder changeBuilder = ChangeRequestInfo.newBuilder().add(toCreate);
//        final ChangeRequestInfo changeRequest = changeBuilder.build();
//        zone.applyChangeRequest(changeRequest);
    }

    public void deleteDNS(final String namespacePrefix) {
        final ConfigUtil reader = new ConfigUtil();
        final Dns dns = DnsOptions.getDefaultInstance().getService();
        final Zone zone = dns.getZone(reader.readJsonConfig().get("zone"));
        final ChangeRequestInfo.Builder changeBuilder = ChangeRequestInfo.newBuilder();

        final String namespaceToDelete = namespacePrefix + "." + zone.getDnsName();

        // If namespace is present delete it
        if(!Iterables.isEmpty(zone.listRecordSets(Dns.RecordSetListOption.dnsName(namespaceToDelete)).iterateAll())){
            final RecordSet recordSet = zone.listRecordSets(Dns.RecordSetListOption.dnsName(namespaceToDelete)).iterateAll().iterator().next();
            changeBuilder.delete(recordSet);
        } else {
            log.info("Namespace Not Present");
        }

        final ChangeRequestInfo changeRequest = changeBuilder.build();
        zone.applyChangeRequest(changeRequest);
    }
}
