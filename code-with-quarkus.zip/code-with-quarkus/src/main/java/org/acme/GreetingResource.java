package org.acme;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import eu.roboflax.cloudflare.CloudflareAccess;
import eu.roboflax.cloudflare.CloudflareCallback;
import eu.roboflax.cloudflare.CloudflareRequest;
import eu.roboflax.cloudflare.CloudflareResponse;
import eu.roboflax.cloudflare.constants.Category;
import eu.roboflax.cloudflare.objects.dns.DNSRecord;
import eu.roboflax.cloudflare.objects.zone.Zone;
import org.acme.service.CloudflareDNSUtil;
import org.acme.service.ConfigUtil;
import org.acme.service.DNSUtil;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;

@Path("/hello")
public class GreetingResource {

//    CloudflareDNSUtil util = new CloudflareDNSUtil();
    DNSUtil util2 = new DNSUtil();
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {

        util2.createDNS("sambit35");
//        util.deleteDNS("example1234");
        return "Hello from asd Reactive";
    }
}